This folder contains the Python library which implements the grading for
CSCE317. The top-level `grade.sh` script calls this folder as a module, with
the entry point being `main.py`.

This library is intentionally included with project skeletons given to
students. Students are welcome to read any of the code in this directory, but
are advised to be aware that a reference version will be used for actual
grading (e.g. if you change code in here, your submission will be graded with
the original version sans your modifications).
