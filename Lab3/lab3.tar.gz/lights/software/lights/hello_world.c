/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <system.h>
#include <alt_types.h>
#include <io.h>
#include <math.h>
#include <unistd.h>
#include <time.h>
#include <stdlib.h>

int main()
{
	int wait_time = 90000;
	while (1){

		// Read key value
		int key = 1;
		key = IORD(0x0, 0); // KEY_BASE = 0x0

		// Set wait time based on key
		switch (key) {
	    	case 13: // key 1
	    		wait_time = 90000;
	    		break;
	    	case 11: // key 2
	    		wait_time = 70000;
	    		break;
	    	case 7: // key 3
	    		wait_time = 50000;
	    		break;
		}

		printf("%i\n", wait_time);
		// wait wait_time
		usleep(wait_time);

		// get a random int between 0 and 26 and set the r-th bit in leds to 1
		int r = rand() % 26;
		int leds = 0 | (1<<r);

		// Write to hardware to start pwm cycle for r-th bit
		IOWR(LED_PWM_0_BASE, 0, leds);	// Write to hardware
	}
	return 0;
}
